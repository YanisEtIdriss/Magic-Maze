from upemtk import *
from fichier import*

def affichage_menu():
  """affiche le menu principal """
  efface_tout()
  texte(690, 234, "Menu principal",couleur='black', ancrage='center', police="Purisa", taille=28)
  rectangle(258, 280, 658, 380,couleur='black', remplissage='green')
  rectangle(678, 280, 1078, 380,couleur='black', remplissage='red')
  rectangle(258, 400, 658, 500,couleur='black', remplissage='gray')
  rectangle(678, 400, 1078, 500,couleur='black', remplissage='gray')
  texte(458, 330, "Jouer",couleur='black', ancrage='center', police="Purisa", taille=24)
  texte(878, 330, "Quitter",couleur='black', ancrage='center', police="Purisa", taille=24)
  texte(458, 450, "Règles",couleur='black', ancrage='center', police="Purisa", taille=24)
  texte(878, 450, "Paramétres",couleur='black', ancrage='center', police="Purisa", taille=24)
  while True:
    x,y,ev = attente_clic()
    if x > 258 and x < 658 and y > 280 and y < 380:
      choix = affichage_choix_lvl()
      if choix != None:
        return choix
      else:
        break
    elif x > 678 and x < 1078 and y > 280 and y < 380:
      ferme_fenetre()
      quit()
    elif x > 258 and x < 658 and y > 400 and y < 500:
      choix = regles("txt/regles/1.txt","Contexte & But","Page 2")
      if choix != None:
        return choix
      else:
        break
    elif x > 678 and x < 1078 and y > 400 and y < 500:
      print("pas encore disponible")

def affichage_interm(string1,string2,string3,mat_sol,mat_mur,temps,Donnees_jeu,liste_tuiles,mat_tuiles):
  """affiche le menu de fin avec string au centre (afin de pouvoir garder le même menu en fonction de pourquoi on y arrivé)
  La fonction retourn None si on reprend la partie, et True si on dois retourner au menu principal (seulement sur le menu pause)"""
  efface_tout()
  texte(690, 234, string1,couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  rectangle(364, 300, 564, 400,couleur='black', remplissage='green')
  rectangle(574, 300, 774, 400,couleur='black', remplissage='gray')
  rectangle(784, 300, 984, 400,couleur='black', remplissage='red')
  texte(464, 350, string2,couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(674, 350, "Sauvegarder",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(884, 350, string3,couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  while True:
    x,y,ev = attente_clic()
    if x > 364 and x < 564 and y > 300 and y < 400:
      return None
    if x > 574 and x < 774 and y > 300 and y < 400:
      if string1 == "Gagné !!!":
        affichage_interm("Pourquoi vouloir sauvegarder ? Vous avez Gagné !",string2,string3,mat_sol,mat_mur,temps,Donnees_jeu,liste_tuiles,mat_tuiles)
        break
      elif string1 == "Perdu !!!":
        affichage_interm("Pourquoi vouloir sauvegarder ? Vous avez Perdu !",string2,string3,mat_sol,mat_mur,temps,Donnees_jeu,liste_tuiles,mat_tuiles)
        break
      else:
        sauvegarder(mat_sol,mat_mur,temps,Donnees_jeu,liste_tuiles,mat_tuiles)
        return affichage_interm("Sauvegardé",string2,string3,mat_sol,mat_mur,temps,Donnees_jeu,liste_tuiles,mat_tuiles)
    if x > 784 and x < 984 and y > 300 and y < 400:
      if string1 == "Pause:":
        return True
      elif string1 == "Sauvegardé":
        return True
      ferme_fenetre()
      quit()

def affichage_choix_lvl():
  """Affiche les différent mode que peut choisir le joueur est renvoie ce choix"""
  efface_tout()
  texte(670, 234, "Choisis un level:",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  rectangle(258, 280, 658, 380,couleur='black', remplissage='gray')
  rectangle(678, 280, 1078, 380, couleur='black', remplissage='gray')
  rectangle(30, 750, 230, 850,couleur='black', remplissage='red')
  rectangle(461, 750, 861, 850,couleur='black', remplissage='gray')
  rectangle(461, 400, 861, 500,couleur='black', remplissage='gray')
  texte(458, 330, "Version Kids ",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(878, 330, "Version Kids Mur",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(661, 450, "Classic",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(661, 800, "Reprendre Sauvegarde",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(130, 800, "Retour",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  while True:
    x,y,ev = attente_clic()
    if x > 30 and x < 230 and y > 750 and y < 850 :
      return affichage_menu()
    elif x > 258 and x < 658 and y > 280 and y < 380 :
      return affichage_nombre_joueurs("1")
    elif x > 678 and x < 1078 and y > 280 and y < 380 :
      return affichage_nombre_joueurs("2")
    elif x > 461 and x < 861 and y > 750 and y < 850 :
      return affichage_nombre_joueurs("sauv")
    elif x > 461 and x < 861 and y > 400 and y < 500 :
      return affichage_nombre_joueurs("3")

def affichage_nombre_joueurs(mode):
  """Affiche les différent mode que peut choisir le joueur est renvoie ce choix"""
  efface_tout()
  texte(670, 234, "Choisis un nombre de joueurs:",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  rectangle(341, 280, 541, 380,couleur='black', remplissage='gray')
  rectangle(561, 280, 761, 380, couleur='black', remplissage='gray')
  rectangle(781, 280, 981, 380, couleur='black', remplissage='gray')
  rectangle(30, 750, 230, 850,couleur='black', remplissage='red')
  texte(441, 330, "1 joueur",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(661, 330, "2 joueurs",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(881, 330, "3 joueurs",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(130, 800, "Retour",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  while True:
    x,y,ev = attente_clic()
    if x > 30 and x < 230 and y > 750 and y < 850 :
      return affichage_choix_lvl()
    elif x > 341 and x < 541 and y > 280 and y < 380 :
      return (mode,1)
    elif x > 561 and x < 761 and y > 280 and y < 380 :
      return (mode,2)
    elif x > 781 and x < 981 and y > 280 and y < 380 :
      return (mode,3)
  return affichage_menu()

def regles(chemin,string1,string2):
  """Affiche les régles à l'aide d'un fichier regle.txt """
  efface_tout()
  rectangle(30, 820, 230, 920,couleur='black', remplissage='red')
  rectangle(1090, 820, 1290, 920,couleur='black', remplissage='green')
  texte(130, 870, "Retour",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(1190, 870, string2,couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  regles_txt = lire_fichier(chemin)
  texte(20, 20, string1 ,couleur='black', ancrage='nw', police="Purisa", taille=20, tag='')
  texte(20, 80, regles_txt ,couleur='black', ancrage='nw', police="Purisa", taille=14, tag='')
  while True:
    x,y,ev = attente_clic()
    if x > 30 and x < 230 and y > 820 and y < 920 :
      break
    if x > 1090 and x < 1290 and y > 820 and y < 920 :
      if "1" in chemin:
          return regles("txt/regles/2.txt","Touches & Levels:","Page 3")
      if "2" in chemin:
        return regles("txt/regles/3.txt","Fonctionalités","Page 1")
      if "3" in chemin:
        return regles("txt/regles/1.txt","Contexte & But","Page 2")
  return affichage_menu()