Présentation :
##############

-Qui a fait le projet ?
Projet réalisé par Idriss Bachi et Yanis Adjou.

-Qu’est-ce que c’est ?
Il s'agit d'un projet scolaire de première année de DUT informatique à l'UPEM, le but était de présenter une version jeux vidéo du célèbre jeu de plateau Magic Maze.

-Quand as-t ’il était réalisé ?
Le projet a été lancé le lundi 12 octobre 2020 et il est toujours en cours.

-Comment on l’installe ?
Il suffit de posséder Python et tkinter sur son ordinateur et d'exécuter le fichier Main.py.

Comment le programme est-il organisé ?
######################################

Notre programme s'organise en trois parties :
---------------------------------------------

Une partie servant à l'importation des modules dont le principal utilisé pour l'interface de notre jeu, upemtk.
____________________________________________________________________________________________________________________________________________________________________________________________
Ensuite, la majorité de notre programme repose sur des fonctions que l'on fait intervenir plus tard dans la boucle principale.
Ces fonctions sont séparées par plusieurs parties :
La première représente les fonctions gérant l'affichage des données ;
La suivante représente les fonctions gérant les données que l'on initialise plus loin ;
Ensuite celles représentent les fonctions testant la validité de ces données en fonctions des règles du jeu ;
La dernière représente les fonctions permettant la lecture des fichiers txt extérieur.
_____________________________________________________________________________________________________________________________________________________________________________________________
Enfin, c'est là que commence notre boucle principale :
Elle commence bien évidemment par notre petite ligne de commande familière " if __name__ == "__main__": "
La première partie contribue à l'initialisation de dictionnaires et listes qui possèdent des données qui ne changeront jamais.
La seconde partie est une boucle du programme permettant de rejouer à l'infini.
La dernière partie est la boucle principale qui fonctionne constamment pendant le jeu. En effet, à l'aide des fonctions prédéfinie, ces dernières change les variables précédemment initialiser. C'est cette partie qui permet à l'utilisateur de jouer.



Quels ont été nos choix techniques ?
###################################

-Un programme entièrement basé sur des fonctions afin d'anticiper la suite du projet.

-L'initialisation de dictionnaires possédant toutes les images à afficher et leurs emplacements ainsi que leurs états. Avec cette méthode il est assez facile de connaitre l'emplacement de tel ou tel élément.
-On a choisi de stocker les règles ainsi que les matrices dans des fichiers texte afin de rendre le code plus lisible.
-Les matrices donnent uniquement les informations sur le terrain, pour chaque case il y a un numéro que l'on relie à une image à l'aide du dictionnaire dic_cases. Cela permet notamment de gérer les murs en effet à chaque fois qu'un pion veut se déplacer on regarde le chemin de la case où il se trouve. Ce chemin a été créé spécialement pour indiquer dans qu'elle direction chacune des images ne permet pas d'aller.


-Le timer fonctionne à l'aide de la fonction time() du module time, on stocke lorsque le moment ou le jeu est lancé dans début et à chaque affichage on fait le temps qu'il est maintenant moins celui qui était au début.
Lorsqu'on met le jeu en pause on compte le temps qui sait écouler pendant cette pose et on rajoute celui-ci à début.
-Nous avons choisi d'utiliser plusieurs listes à trous pour rendre le programme plus efficace.

Quels ont été les éventuels problèmes rencontrés ?
##################################################

Actuellement l'affiche est effacée puis réaffichée à chaque boucle du programme. Cette façon de faire n'est pas la plus efficace mais nous n'avons pas réussi à faire autrement pour l'instant. En effet pendant que l'on réfléchissait comment programmer le jeu nous ne connaissions pas l'existence des tags et de la possibilité d'effacer que certaines images.
_____________________________________________________________________________________________________________________________________________________________________________________________
La principale difficulté rencontrée fut de maintenir un code compréhensible et efficace. Nous avons donc beaucoup réfléchi sur les meilleurs maniérés de faire pour chaque chose implémenter. Le but était de ne pas faire des if et elif à la chaine. 
Notre principal problème rencontré fut alors de tout penser en amont.
Malgré cela nous avons quand même rencontré des problèmes lorsque nous avons commencé à coder car nous n’avions pas totalement pensé à tout. Cependant comme nous avions des objectifs et de manière de faire clairement défini et un code lisible nous avons réussi à passer outre ces problèmes.
_____________________________________________________________________________________________________________________________________________________________________________________________
Au niveau des graphismes il a été difficile de faire en sorte que toutes les cases soient liées.
Trouver le compromis entre résolutions petites mais assez grand pour pouvoir faire quelque chose de propre.





Changelog(ce qui a été implémenté):
###################################
Version 1.0 du Lundi 2nov :
--------------------------
-Jouable seulement en solo on contrôle les 4 pions et on peut prendre les objets et sortir.
-On peut choisir entre deux modes kids un avec des murs et l'autre sans-Le terrain est constitué d'un labyrinthe vide toujours identique mais d'on l'emplacement des objets, des pions ainsi que des sorties sont aléatoires parmi plusieurs cases présélectionnées.
-Il y a un timer qui affiche un décompte de 180 jusqu'à 0 une fois arriver à 0 s'est perdu.
-Il y a un sélecteur qui permet au joueur de toujours connaître le pion actuellement sélectionné.
-Il existe un mode débug permettant de déplacer les pions de façon aléatoire afin de tester le programme.
-Le jeu une fois lancé est rejouable à l'infini grâce à un menu disponible permettant de guider le joueur.
-Le menu du début possède l'option Règles qui affiche les règles du jeu mais aussi l'option paramètre qui n'est pas encore disponible.
-Les autres menus permettant uniquement de rejouer et de quitter, l'option sauvegardée n'est pas encore disponible.
