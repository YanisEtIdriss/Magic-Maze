#--------------------------------------------------------------Imports-----------------------------------------------------------------
from upemtk import * 
from time import time, sleep
from random import choice, randint
#--------------------------------------------------------------Fonctions-----------------------------------------------------------------
#Fonctions gérant l'affichage des données
def affichage_main(pion,L,debug,mat,debut):
  mise_a_jour()
  efface_tout()
  affichage(mat)
  gestion_mat()
  Selecteur(pion,L,debug)
  return [temp(debut,time()),gagner_check()]

def affichage(mat):
  """gère l’affichage notamment  la  correspondance  entre la structure de donnees et les cases affichees"""
  for i in range(len(mat[0])):
    for j in range(len(mat)):
      image(i*72, j*72, dic_cases[mat[j][i]], ancrage='nw')
  if Donnees_jeu["images/casesortie/sortie_1.png"][2]:
    image(540,756,"images/menu/etat2.png",ancrage='center')
  else:
    image(540,756,"images/menu/etat.png",ancrage='center')

def gestion_mat():
  """maintient  toutes  les  donnees  du  jeu  (emplacement  des  ́elements  sur  la  grille,position des pions, objets recuperes"""
  for i in Donnees_jeu.items():
    if not Donnees_jeu[i[0]][2] or "sortie" in i[0]:
      image(i[1][0]*72, i[1][1]*72, i[0], ancrage='nw')

def affichage_menu():
  """affiche le menu principal """
  efface_tout()
  texte(540, 400, "Menu principal",couleur='black', ancrage='center', police="Purisa", taille=24)
  rectangle(330, 450, 530, 550,couleur='black', remplissage='green')
  rectangle(550, 450, 750, 550,couleur='black', remplissage='red')
  rectangle(330, 570, 530, 670,couleur='black', remplissage='gray')
  rectangle(550, 570, 750, 670,couleur='black', remplissage='gray')
  texte(430, 500, "Jouer",couleur='black', ancrage='center', police="Purisa", taille=24)
  texte(650, 500, "Quitter",couleur='black', ancrage='center', police="Purisa", taille=24)
  texte(430, 620, "Règles",couleur='black', ancrage='center', police="Purisa", taille=24)
  texte(650, 620, "Paramétres",couleur='black', ancrage='center', police="Purisa", taille=24)
  while True:
    x,y,ev = attente_clic()
    if x > 330 and x < 530 and y > 450 and y < 550:
      choix = affichage_choix_lvl()
      if choix != None:
        return choix
      else:
        break
    elif x > 550 and x < 750 and y > 450 and y < 550:
      ferme_fenetre()
      quit()
    elif x > 330 and x < 530 and y > 570 and y < 670:
      choix = regles()
      if choix != None:
        return choix
      else:
        break
    elif x > 550 and x < 750 and y > 570 and y < 670:
      print("En cours")

def affichage_interm(string1,string2,string3):
  """affiche le menu de fin avec string au centre (afin de pouvoir garder le même menu en fonction de pourquoi on y arrivé)
  La fonction retourn None si on reprend la partie, et True si on dois retourner au menu principal (seulement sur le menu pause)"""
  efface_tout()
  texte(540, 400, string1,couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  rectangle(220, 450, 420, 550,couleur='black', remplissage='green')
  rectangle(440, 450, 640, 550,couleur='black', remplissage='gray')
  rectangle(660, 450, 860, 550,couleur='black', remplissage='red')
  texte(320, 500, string2,couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(540, 500, "Sauvegarder",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(760, 500, string3,couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  while True:
    x,y,ev = attente_clic()
    if x > 220 and x < 420 and y > 450 and y < 550:
      return None
    if x > 440 and x < 640 and y > 450 and y < 550:
      if string1 == "Gagné !!!":
        affichage_interm("Pourquoi vouloir sauvegarder ? Vous avez Gagné !",string2,string3)
        break
      elif string1 == "Perdu !!!":
        affichage_interm("Pourquoi vouloir sauvegarder ? Vous avez Perdu !",string2,string3)
        break
      else:
        affichage_interm("Pas encore implémenter",string2,string3)
        break
    if x > 660 and x < 860 and y > 450 and y < 550:
      if string1 == "Pause:":
        return True
      ferme_fenetre()
      quit()

def affichage_choix_lvl():
  efface_tout()
  texte(540, 300, "Choisis un level",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  rectangle(120, 350, 520, 450,couleur='black', remplissage='gray')
  rectangle(560, 350, 960, 450,couleur='black', remplissage='gray')
  rectangle(30, 650, 230, 750,couleur='black', remplissage='red')
  texte(320, 400, "Version Kids Mur",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(760, 400, "Version Kids",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  texte(130, 700, "Retour",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  while True:
    x,y,ev = attente_clic()
    if x > 30 and x < 230 and y > 650 and y < 750 :
      break
    elif x > 120 and x < 520 and y > 350 and y < 450 :
      return "1"
    elif x > 560 and x < 960 and y > 350 and y < 450 :
      return "2"

  affichage_menu()

def regles():
  """Affiche les régles à l'aide d'un fichier regle.txt """
  efface_tout()
  rectangle(30, 650, 230, 750,couleur='black', remplissage='red')
  texte(130, 700, "Retour",couleur='black', ancrage='center', police="Purisa", taille=24, tag='')
  regles = lire_fichier("txt/regle.txt")
  texte(0, 0, regles ,couleur='black', ancrage='nw', police="Purisa", taille=12, tag='')
  while True:
    x,y,ev = attente_clic()
    if x > 30 and x < 230 and y > 650 and y < 750 :
      break
  return affichage_menu()

def temp(debut,present):
  """Affiche le temps qu'il reste en secondes en prenant en argument le temp auxquelle on as débuté et celui qu'il est maintenant
  la fonction retourne un booléen permettant de savoir si le joueur à perdu(True) ou non(False) à l'aide de la fonction perdu_check"""
  texte(850, 755,"Temps restant:" + str(int(180-(present-debut))),couleur='black', ancrage='center', taille=20, tag='')
  image(1040,755,"images/menu/sablier.png",ancrage='center')
  return perdu_check(int(180-(present-debut)))

def Selecteur(pion,liste_pion,debug):
  """affiche le selecteur de pion en fonction du pion sélectioné (pion) et de la liste des pions jouable (liste_pion)"""
  if debug:
    texte(250, 755, "Mode debug Activé",couleur='black', ancrage='center', police="Purisa", taille=24)
  else:
    for i in range(len(liste_pion)):
      n = int(liste_pion[i][-5])
      image(n*100,755, liste_pion[i], ancrage='center')
      if pion == liste_pion[i]:
        cercle(n*100,755,35,couleur='red', remplissage='', epaisseur=2, tag='')
      else:
        cercle(n*100,755,35,couleur='black', remplissage='', epaisseur=2, tag='')

#fonctions gérant les données
def bouger_pion(player,touche):
  """permet au joueur de bouger ses pions, on bouge le player en fonction de la touche"""
  if touche == avancer and pions_mur(player,"H",mat) and pions_pion((Donnees_jeu[player][0],Donnees_jeu[player][1]-1),convertir(liste_pion)):
    Donnees_jeu[player] = (Donnees_jeu[player][0],Donnees_jeu[player][1]-1,Donnees_jeu[player][2])
  elif touche == gauche and pions_mur(player,"G",mat) and pions_pion((Donnees_jeu[player][0]-1,Donnees_jeu[player][1]),convertir(liste_pion)):
    Donnees_jeu[player] = (Donnees_jeu[player][0]-1,Donnees_jeu[player][1],Donnees_jeu[player][2])
  elif touche == reculer and pions_mur(player,"B",mat) and pions_pion((Donnees_jeu[player][0],Donnees_jeu[player][1]+1),convertir(liste_pion)):
    Donnees_jeu[player] = (Donnees_jeu[player][0],Donnees_jeu[player][1]+1,Donnees_jeu[player][2])
  elif touche == droite and pions_mur(player,"D",mat) and pions_pion((Donnees_jeu[player][0]+1,Donnees_jeu[player][1]),convertir(liste_pion)):
    Donnees_jeu[player] = (Donnees_jeu[player][0]+1,Donnees_jeu[player][1],Donnees_jeu[player][2])
  return check_objet_sortie(player,Donnees_jeu[player])

def debug_mode(pion,touche):
  for i in range(randint(1,5)):
    bouger_pion(pion,touche)
    
def changer_joueur(player,L):
  """Permet à l'utilisateur de sélectinner un pion différent en fonction de celui déjà selectionné(player)
  et des pions possible(L)"""
  for i in range(len(L)):
    if L[i]==player:
      if i == len(L)-1:
        return L[0]
      return L[i+1]
  return player

def assigniation():
  """Permet d'assigner au objet et sortie à des positions aléatoire parmis celle noté dans la liste pos_possible_objet_sortie"""
  for i in Donnees_jeu.items():
    while True:
      if "pion" in i[0]:
        n = randint(0,len(pos_possible_pion[0])-1)
        if n not in pos_possible_pion[1]:
          pos_possible_pion[1].append(n)
          Donnees_jeu[i[0]] = pos_possible_pion[0][n]
          break
      else:
        n = randint(0,len(pos_possible_objet_sortie[0])-1)
        if n not in pos_possible_objet_sortie[1]:
          pos_possible_objet_sortie[1].append(n)
          Donnees_jeu[i[0]] = pos_possible_objet_sortie[0][n]
          break
      
def convertir(L):
    """Renvoie une liste "classique" contenant les  éléments apparaissant
    réellement dans L."""
    L2 =[]
    for i in range(len(L[0])):
        if i not in L[1]:
            L2.append(L[0][i])
    return L2
#Tests pour les données
def pions_mur(player,lettre,mat):
  """retourne un bolléen symbolisant si oui ou non un pion peu avancer en fonction des murs de la case ou il se trouve"""
  return lettre not in dic_cases[mat[Donnees_jeu[player][1]][Donnees_jeu[player][0]]]

def pions_pion(player,L):
  """Regarde dans L si il existe un pion au même coordonnées que player, si c'est le cas on renvoie False car on ne peux pas avancer
  ce pion dans cette case. player correspond aux coordonnées possible du pions sélectionné si on effectuais le déplacement choisi."""
  test = True
  for i in range(len(L)):
    if player == (Donnees_jeu[L[i]][0],Donnees_jeu[L[i]][1]): 
      test = False
  return test

def check_objet_sortie(player,donnee):
  """effectue les check d'objet et de sortie et permet de renvoyer le prochain pion qu'on pourras bouger"""
  objet_check()
  nv_pion = sortie_check(player,donnee)
  if nv_pion != None:
    return nv_pion

def objet_check():
  """regarde si le pion est sur la position où se trouve son objet et si c'est le cas alors l'objet et la sortie passe en true"""
  test = True
  for i in Donnees_jeu.items():
    if "objet" in i[0]:
      player = "images/pion/pion"+i[0][-5]+".png"
      player_cord=(Donnees_jeu[player][0],Donnees_jeu[player][1],Donnees_jeu[player][2])
      if i[1] != player_cord and player[-5] == i[0][-5]:
        test = False
  if test:
    for i in Donnees_jeu.items():
      if "objet" in i[0]:
        Donnees_jeu[i[0]]=(i[1][0],i[1][1],True)
    
def sortie_check(player,player_cord):
  """regarde si le pion est sur la position où se trouve sa sortie et si c'est le cas alors l'objet passe en true"""
  for i in Donnees_jeu.items():
    if "sortie" in i[0] and i[1][0] == player_cord[0] and i[1][1] == player_cord[1] and player[-5] == i[0][-5] and Donnees_jeu["images/objet/objet"+i[0][-5]+".png"][2]:
      Donnees_jeu[player]=(Donnees_jeu[player][0],Donnees_jeu[player][1],True)
      for j in range(len(liste_pion[0])):
        if player == liste_pion[0][j]:
          nv_pion = changer_joueur(player,convertir(liste_pion))
          liste_pion[1].append(j)
          return nv_pion
      
def gagner_check():
  """test si la partie est gagné"""
  test = True
  for i in Donnees_jeu.items():
    if "pion" in i[0]:
      if not Donnees_jeu[i[0]][2]:
        return None
  if test:
    return True

def perdu_check(temp):
  """test si la partie est perdu en fonction du temp qu'il reste"""
  if int(temp) <= 0:
    return True

def test_gagner_perdu(L):
  if L[1] == True:
    affichage_interm("Gagné !!!","Menu","Quitter")
    return True
  elif L[0] == True:
    affichage_interm("Perdu !!!","Menu","Quitter")

def test_touches(debut,attente,joueur_select,debug):
  touche = attente_touche_jusqua(attente)
  if touche == "dollar":
    debug = not debug
    if not debug:
      return(True,debut,joueur_select,1000,debug)
  if debug:
    return(True,debut,joueur_select,0.001,debug)   
  elif touche == "Escape":
    temp_pose = time()
    condition = affichage_interm("Pause:","Reprendre","Menu")
    if condition:
      return(False,debut,joueur_select,1000,debug)
    debut += time()-temp_pose
    return(True,debut,joueur_select,1000,debug)
  elif touche == "e":
    joueur_select = changer_joueur(joueur_select,convertir(liste_pion))
  elif touche == avancer or touche == gauche or touche == reculer or touche == droite:
    nv_pion = bouger_pion(joueur_select,touche)
    if nv_pion != None:
      joueur_select = nv_pion
      return(True,debut,nv_pion,1000,debug)
  return(True,debut,joueur_select,1000,debug)
#Fonction sur les fichiers
def lire_fichier(chemin):
  """Lis un fichier et renvoie son texte"""
  fichier = open(chemin, 'r')
  texte = ""
  for lignes in fichier:
    texte += lignes
  fichier.close() 
  return texte

def extraire_matrice(chemin):
  """Lis un fichier et renvoie la matrice qu'il contient"""
  fichier = open(chemin, 'r')
  mat = []
  for lignes in fichier:
    mat.append([])
    L = lignes.split(",")
    for i in range(len(L)):
      if L[i] != "\n":
        mat[-1].append(int(L[i]))
  return mat  
#--------------------------------------------------------Partie principal----------------------------------------------------------
if __name__ == "__main__":
  """boucle principal qui controle le jeu et la gestion des touches """
#Dictionnaire liant les numéro dans la matrice à une image 
  dic_cases = {0:'images/casevide/in.png',1:'images/casevide/vide.png',2:'images/casevide/D.png',3:'images/casevide/G.png',4:'images/casevide/H.png',
  5:'images/casevide/B.png',6:'images/casevide/HB.png',7:'images/casevide/GD.png',8:'images/casevide/BD.png',9:'images/casevide/BG.png',10:'images/casevide/HD.png',
  11:'images/casevide/HG.png',12:'images/casevide/GHD.png',13:'images/casevide/GBD.png',14:'images/casevide/HGB.png',15:'images/casevide/HDB.png'}
#Dictionnaire stockant les coordonnées des pions, objets et sorties
  Donnees_jeu = {"images/objet/objet1.png":(0),"images/objet/objet2.png":(0),"images/objet/objet3.png":(0),"images/objet/objet4.png":(0),
  "images/casesortie/sortie_1.png":(0),"images/casesortie/sortie_2.png":(0),"images/casesortie/sortie_3.png":(0),"images/casesortie/sortie_4.png":(0),
  "images/pion/pion1.png":(0),"images/pion/pion2.png":(0),"images/pion/pion3.png":(8,4,False),"images/pion/pion4.png":(8,5,False)}
  pos_possible_pion = [[(6,4,False),(6,5,False),(8,4,False),(8,5,False)],[]]
  pos_possible_objet_sortie = [[(13,3,False),(12,0,False),(2,3,False),(0,2,False),(12,9,False),
  (14,0,False),(0,9,False),(14,9,False),(2,1,False),(8,3,False),(8,6,False),(10,5,False),(9,8,False),(13,7,False),(0,3,False)],[]]
#creation de la fenetre
  cree_fenetre(1080, 792)
#boucle du programme
  while True:
#affichage du menu
    choix = affichage_menu()
    mat = extraire_matrice("txt/mat_"+choix+".txt")
#Remet à 0 les positions utiliser et assigne des nouvelles
    pos_possible_pion[1],pos_possible_objet_sortie[1]=[],[]
    assigniation()
#Initialisation des variables
    activer,debug,gagner,perdu= True,False,False,False
    liste_pion=[["images/pion/pion1.png", "images/pion/pion2.png", "images/pion/pion3.png", "images/pion/pion4.png"],[]]
    avancer, reculer, droite, gauche = "z","s","d","q"
    liste_touche=[avancer, reculer, droite, gauche]
    joueur_select = "images/pion/pion1.png"
    attente = 1
    debut= time()
#boucle principale
    while activer:
      if debug == True:
        debug_mode(choice(convertir(liste_pion)), choice(liste_touche))
      L = test_touches(debut,attente,joueur_select,debug)
      activer = L[0]
      debut = L[1]
      joueur_select = L[2]
      attente = L[3]
      debug = L[4]
      L = affichage_main(joueur_select,convertir(liste_pion),debug,mat,debut)
      test = test_gagner_perdu(L)
      if test:
        break