#--------------------------------------------------------------Imports-----------------------------------------------------------------
from upemtk import * 
from menu import *
from time import time
from random import choice, randint, shuffle
from fichier import *
#--------------------------------------------------------------Fonctions-----------------------------------------------------------------
#Fonctions gérant l'affichage des données
def affichage_main(pion,debug,debut,list_direction):
  """Gere l'affichage générale d'une partie"""
  mise_a_jour()
  gestion_mat()
  Selecteur(pion,debug,list_direction)
  return [temp(debut,time()),gagner_check()]

def affichage():
  """gère l’affichage notamment  la  correspondance  entre la structure de donnees et les cases affichees"""
  efface("mat")
  for i in range(len(mat_sol[0])):
    for j in range(len(mat_sol)):
      if mat_sol[j][i] != 0:
        if 'objet' in dic_cases[mat_sol[j][i]]:
          if not Donnees_jeu["images/pion/"+dic_cases[mat_sol[j][i]][-5]+".png"][3]:
            image(i*52, j*52, dic_cases[mat_sol[j][i]], ancrage='nw', tag="mat")
          else: 
            image(i*52, j*52, 'images/vide.png', ancrage='nw', tag="mat")
        else:
            image(i*52, j*52, dic_cases[mat_sol[j][i]], ancrage='nw', tag="mat")
      if mat_mur[j][i] != 0:
        image(i*52, j*52, dic_cases[mat_mur[j][i]], ancrage='nw', tag="mat")

def gestion_mat():
  """maintient  toutes  les  donnees  du  jeu  (emplacement  des  ́elements  sur  la  grille,position des pions, objets recuperes"""
  efface("donnee")
  for i in Donnees_jeu.items():
    if not Donnees_jeu[i[0]][2]:
      image(i[1][0]*52, i[1][1]*52, i[0], ancrage='nw',tag="donnee")

def temp(debut,present):
  """Affiche le temps qu'il reste en secondes en prenant en argument le temp auxquelle on as débuté et celui qu'il est maintenant
  la fonction retourne un booléen permettant de savoir si le joueur à perdu(True) ou non(False) à l'aide de la fonction perdu_check."""
  efface("temp")
  temp = int(180-(present-debut))
  if temp > 90:
    texte(1350, 890,"Temps:" + str(temp),couleur='white', ancrage='center', taille=24, tag="temp")
    rectangle(1257,910,1437-(present-debut),930,couleur='white', remplissage='green', tag='temp')
  else:
    texte(1350, 890,"Temps:" + str(temp),couleur='red', ancrage='center', taille=24, tag="temp")
    rectangle(1257,910,1437-(present-debut),930,couleur='white', remplissage='red', tag='temp')
  rectangle(1437-(present-debut),910,1437,930, couleur='white', tag='temp')
  return perdu_check(int(180-(present-debut)))

def Selecteur(pion,debug,list_direction):
  """affiche le selecteur de pion pour"""
  efface("selecteur")
  if debug:
    texte(1350,200, "Mode debug",couleur='black', ancrage='center', police="Purisa", taille=22,tag="selecteur")
  else:
    for j in range(len(pion)):
      for i in range(len(liste_pion[0])):
        pos_titre = (j+1)*200
        texte(1350,pos_titre, "Joueur "+str(j+1),couleur='white', ancrage='center', police="Purisa", taille=24,tag="selecteur")
        n = int(liste_pion[0][i][-5])
        image(1150+n*40,pos_titre+50, liste_pion[0][i], ancrage='center',tag="selecteur")
        if pion[j][-5] == liste_pion[0][i][-5]:
          cercle(1150+n*40,pos_titre+50,20,couleur='red', remplissage='', epaisseur=2,tag="selecteur")
        else:
          cercle(1150+n*40,pos_titre+50,20,couleur='white', remplissage='', epaisseur=2,tag="selecteur")
      if len(direction_posible[j])>1:
        for l in range(len(direction_posible[j])):
          image(1264+(l+1)*35,pos_titre+100, "images/fleche/"+direction_posible[j][l]+".png", ancrage='center',tag="selecteur")
          if direction_posible[j][l] == list_direction[j][0]:
            cercle(1264+(l+1)*35,pos_titre+100,15,couleur='red', remplissage='', epaisseur=2,tag="selecteur")
          else:
            cercle(1264+(l+1)*35,pos_titre+100,15,couleur='white', remplissage='', epaisseur=2,tag="selecteur")
      else:
        image(1264+35,pos_titre+100, "images/fleche/"+direction_posible[j][0]+".png", ancrage='center',tag="selecteur")
        if direction_posible[j][0] == list_direction[j][0]:
          cercle(1264+35,pos_titre+100,15,couleur='red', remplissage='', epaisseur=2,tag="selecteur")
        else:
          cercle(1264+35,pos_titre+100,15,couleur='white', remplissage='', epaisseur=2,tag="selecteur")
      for i in range(len(pouvoir[j])):
        image(1264+(i+1)*35,pos_titre+150,"images/pouvoirs/"+pouvoir[j][i]+".png" , ancrage='center',tag="selecteur")

#fonctions gérant les données
def bouger_pion(pion,direction,pos,debut):
  """permet aux joueurs de bouger leurs pions, on bouge le pion en fonction de la touche"""
  dico_direction_inverse = {'H':'B','G':'D','D':'G','B':'H'}
  murs = ['H','G','D','B']
  mouvement = [(0,-1),(-1,0),(1,0),(0,1)]
  if not Donnees_jeu[pion][2]:
    for i in range(4):
      if pion[-5] == 1 or direction == liste_touche[i] and pions_mur((Donnees_jeu[pion][0],Donnees_jeu[pion][1]),murs[i]) and pions_pion((Donnees_jeu[pion][0]+mouvement[i][0],Donnees_jeu[pion][1]+mouvement[i][1]),convertir(liste_pion)):
        if "explo" in dic_cases[mat_sol[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]]]:
          if not pions_mur((Donnees_jeu[pion][0]+mouvement[i][0],Donnees_jeu[pion][1]+mouvement[i][1]),dico_direction_inverse[murs[i]]):
            return debut
          if "pion" in pion:
            if dans_tuile("garde",mat_tuiles[Donnees_jeu[pion][1]+mouvement[i][1]][Donnees_jeu[pion][0]+mouvement[i][0]]):
              return debut 
          else:
            if dans_tuile("pion",mat_tuiles[Donnees_jeu[pion][1]+mouvement[i][1]][Donnees_jeu[pion][0]+mouvement[i][0]]):
              return debut
        Donnees_jeu[pion] = (Donnees_jeu[pion][0]+mouvement[i][0],Donnees_jeu[pion][1]+mouvement[i][1],Donnees_jeu[pion][2],Donnees_jeu[pion][3])
        debut = sablier(pion,debut,time())
        objet_check()
        sortie_check(pion,Donnees_jeu[pion],pos)
  return debut
    
def debug_mode(pion,touche):
  """Apelle la fonction bouger de 1 à 5 fois pour des valeur donné """
  for i in range(randint(1,5)):
    bouger_pion(pion,touche,0,debut)
    
def changer_joueur(pion,L,pos):
  """Permet à l'utilisateur de sélectinner un pion différent en fonction de celui déjà selectionné
  et des pions possible(L)"""
  nv_pion = pion[pos]
  for i in range(len(L)):
    if L[i]==pion[pos]:
      if i == len(L)-1:
        nv_pion = L[0]
      else:
        nv_pion = L[i+1]
  pion[pos]=nv_pion
      
def convertir(L):
    """Renvoie une liste "classique" contenant les  éléments apparaissant
    réellement dans L."""
    L2 =[]
    for i in range(len(L[0])):
        if L[0][i] not in L[1]:
          L2.append(L[0][i])
    return L2

def affectation_direct_pvr(choix):
  """Affecte les direction possible ainsi que les pouvoir en fonction du nombre de joueur choisi"""
  if choix == 1:
    return ([["avancer","reculer","droite","gauche"]],[["esc","expl","télé"]])
  elif choix == 2:
    choix_pos_direct = [[["avancer","reculer"],["droite","gauche"]],[["avancer","droite"],["reculer","gauche"]],[["avancer","gauche"],["reculer","droite",]]]
    choix_pos_pvr = [[["esc","expl"],["télé"]],[["esc","télé"],["expl"]],[["expl","télé"],["esc"]]]
    n,m = randint(0,2),randint(0,2)
    direct = choix_pos_direct[n]
    pvr = choix_pos_pvr[m]
  else:
    choix_pos_direct = [[["avancer","droite"],["gauche"],["reculer"]],[["avancer","gauche"],["droite"],["reculer"]],[["avancer","reculer"],["droite"],["gauche"]],[["droite","gauche"],["avancer"],["reculer"]],[["reculer","droite"],["avancer"],["gauche"]],[["reculer","gauche"],["avancer"],["droite"]]]
    pvr = [["esc"],["expl"],["télé"]]
    n = randint(0,5)
    direct = choix_pos_direct[n]
  shuffle(direct)
  shuffle(pvr)
  for i in range(len(direct)):
    shuffle(direct[i])
    shuffle(pvr[i])
  return direct,pvr

def teleportation(pion,coord):
  """Permet à pion en coordonnées coord de se téléporter vers une case téléportation"""
  image = dic_cases[mat_sol[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]]]
  if "teleport" in image and pion[-5] == image[-5] and not Donnees_jeu[pion][3]:
    list_pos_tel = []
    for i in range(len(mat_sol)):
      for j in range(len(mat_sol[0])):
        if mat_sol[i][j] == mat_sol[coord[1]][coord[0]]:
          list_pos_tel.append((i,j))
    for i in range(len(list_pos_tel)):
      if list_pos_tel[i] == (coord[1],coord[0]):
        if i == len(list_pos_tel)-1:
          Donnees_jeu[pion] = (list_pos_tel[0][1],list_pos_tel[0][0],Donnees_jeu[pion][2],Donnees_jeu[pion][3])
        else:
          Donnees_jeu[pion] = (list_pos_tel[i+1][1],list_pos_tel[i+1][0],Donnees_jeu[pion][2],Donnees_jeu[pion][3])
  if dans_tuile("garde",mat_tuiles[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]]):
    teleportation(pion,(Donnees_jeu[pion][0],Donnees_jeu[pion][1]))
def escalator(pion,coord):
  """Permet à pion en coordonnées coord de monter ou descendre les cases escalators"""
  if mat_mur[coord[1]][coord[0]] != 0 and "E" in dic_cases[mat_mur[coord[1]][coord[0]]]:
    deplacement=[(coord[0]+1,coord[1]-1),(coord[0]-1,coord[1]+1),(coord[0]+1,coord[1]+1),(coord[0]-1,coord[1]-1),(coord[0]+2,coord[1]-1),(coord[0]-2,coord[1]+1),(coord[0]-1,coord[1]-2),(coord[0]+1,coord[1]+2),(coord[0]+1,coord[1]-2),(coord[0]-2,coord[1]-1),(coord[0]-1,coord[1]+2),(coord[0]+2,coord[1]+1)]
    for x,y in deplacement:
      if 0<x<len(mat_mur[0]) and 0<y<len(mat_mur):
        verif_escalator = mat_mur[y][x]
        if verif_escalator != 0:
          if "E" in  dic_cases[mat_mur[y][x]] and mat_tuiles[y][x] == mat_tuiles[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]]:
            Donnees_jeu[pion] = (x,y,Donnees_jeu[pion][2],Donnees_jeu[pion][3])
            break

def exploration(pion,coord):
  """permet aux joueurs de faire apparraitre des tuiles à l'endroit où ils se trouvent"""
  dico_orientation ={'H':[(-4,0),(-1,+3),(-1,0)],'B':[(1,5),(-2,2),(1,0)],'G':[(-2,2),(-4,0),(0,-1)],'D':[(-1,3),(1,5),(0,1)]}
  if pion == "laissez passer":
    tuile = bonne_tuile(pion,coord,dico_orientation,False)
  else:
    tuile = bonne_tuile(pion,coord,dico_orientation,True)
  if tuile[1] == 0:
    return None
  placer_tuile(tuile[0],tuile[1],coord,dico_orientation,None)

def placer_tuile(num_tuile, orientation_tuile,coord,dico_orientation, condition):
  """Place la tuile de num num_tuile avec l'orientation orientation_tuile aux position coord"""
  mat_sol_explo,mat_mur_explo = extraire_matrice("txt/matrice/"+str(num_tuile)+"/"+orientation_tuile+"/mat_2.txt"),extraire_matrice("txt/matrice/"+str(num_tuile)+"/"+orientation_tuile+"/mat_1.txt")
  for m in dico_orientation:
    if orientation_tuile == m:
      if coord[0]<4 and m == 'G' or coord[0]>= 19 and m == 'D' or coord[1]<=4 and m == 'H'  or coord[1] >= 16 and m == 'B':
        return None
      if condition == None and mat_sol[coord[1]+dico_orientation[m][2][0]][coord[0]+dico_orientation[m][2][1]] != 0 or mat_mur[coord[1]+dico_orientation[m][2][0]][coord[0]+dico_orientation[m][2][1]] ==61:
        return None
      else:
        k = 0
        l = 0
        for j in range(coord[1]+dico_orientation[m][0][0],coord[1]+dico_orientation[m][0][1]):
          for i in range(coord[0]+dico_orientation[m][1][0],coord[0]+dico_orientation[m][1][1]):
            mat_sol[j][i]=mat_sol_explo[k][l]
            mat_mur[j][i]=mat_mur_explo[k][l]
            mat_tuiles[j][i]=num_tuile
            if num_tuile == 9 or num_tuile=="9" and mat_sol_explo[k][l] == 78:
              x_garde,y_garde = i,j
            l+=1
          k+=1
          l=0
  if num_tuile == 9 or num_tuile=="9":
    Donnees_jeu["images/garde/5.png"]=(x_garde,y_garde,False,False)
  liste_tuiles[1].append(num_tuile)
  affichage()

def sablier(pion,debut,present):
  """Permet de retourner le sablier"""
  coord = (Donnees_jeu[pion][0],Donnees_jeu[pion][1])
  if mat_sol[coord[1]][coord[0]] == 69 and "garde" not in pion:
    mat_sol[coord[1]][coord[0]] = 68
    temp_ecoule = (present-debut)
    temp_restant = (180 - temp_ecoule)
    modif = temp_ecoule - temp_restant
    debut += modif
    affichage()
    return debut
  return debut

def sort_violet(coord,compte):
  """Permet de faire apparaitre des tuiles à distance"""
  if len(convertir(liste_tuiles)) == 0:
    mat_sol[coord[0]][coord[1]] = 78
  dico_orientation ={'H':[(-4,0),(-1,+3),(-1,0)],'B':[(1,5),(-2,2),(1,0)],'G':[(-2,2),(-4,0),(0,-1)],'D':[(-1,3),(1,5),(0,1)]}
  endroit_possible = trouver_cases_explo_sort("sort_violet", dico_orientation)
  texte(150,0,"Clique Gauche à l'endroit voulu, clique Droit pour quitter",tag="sort_violet")
  while True:
    x,y,ev = attente_clic()
    if (x//52,y//52) in endroit_possible:
      if ev == "ClicGauche":
        exploration("laissez passer",(x//52,y//52))
        if compte == 2:
          sort_violet(coord,1)
        else:
          mat_sol[coord[0]][coord[1]] = 78
      break
    elif ev == "ClicDroit": 
      mat_sol[coord[0]][coord[1]] = 78
      break
  efface("sort_violet")
  affichage()

def sort_vert():
  """Permet de déplacer des tuiles"""
  global pouvoir_vert
  if pouvoir_vert < 2:
    dico_orientation ={'H':[(-4,0),(-1,+3),(-1,0)],'B':[(1,5),(-2,2),(1,0)],'G':[(-2,2),(-4,0),(0,-1)],'D':[(-1,3),(1,5),(0,1)]}
    endroit_possible = []
    for i in range(len(mat_sol[0])):
      for j in range(len(mat_sol)):
        if mat_sol[j][i] != 0 and "explo" in dic_cases[mat_sol[j][i]] and dic_cases[mat_sol[j][i]][-6]=="/":
          endroit_possible.append((i,j))
    for x,y in endroit_possible:
      rectangle(x*52,y*52,x*52+52,y*52+52,couleur="green",tag="sort_vert",epaisseur=6)
    texte(150,0,"Clique Gauche à l'endroit voulu, clique Droit pour quitter",tag="sort_vert")
    while True:
      x,y,ev = attente_clic()
      if (x//52,y//52) in endroit_possible:
        if ev == "ClicGauche":
          tuile_select = mat_tuiles[y//52][x//52]
          if not dans_tuile("pion",tuile_select) and not dans_tuile("garde",tuile_select):
            break
      elif ev == "ClicDroit": 
        break
    efface("sort_vert")
    endroit_possible = trouver_cases_explo_sort("sort_vert",dico_orientation)
    texte(150,0,"Clique Gauche à l'endroit voulu, clique Droit pour quitter",tag="sort_vert")
    while True:
      x,y,ev = attente_clic()
      if (x//52,y//52) in endroit_possible:
        if ev == "ClicGauche":
          tuile_orientation = dic_cases[mat_sol[y//52][x//52]][-5]
          for i in range(len(mat_sol[0])):
            for j in range(len(mat_sol)):
              if mat_tuiles[j][i] == tuile_select:
                mat_sol[j][i] = 0
                mat_mur[j][i] = 0
          placer_tuile(str(tuile_select),tuile_orientation,(x//52,y//52),dico_orientation,"vert")
          pouvoir_vert += 1
          break
      elif ev == "ClicDroit": 
        break
    efface("sort_vert")
    affichage()

def trouver_cases_explo_sort(tag, dico_orientation):
  """Permet des trouver les cases exploration et en renvoyer une liste avec leurs coordonnées"""
  endroit_possible=[]
  for i in range(len(mat_sol[0])):
    for j in range(len(mat_sol)):
      if mat_sol[j][i] not in [0,17,18,19,20] and "explo" in dic_cases[mat_sol[j][i]]:
        lettre = dic_cases[mat_sol[j][i]][-5]
        if not (i<4 and lettre == 'G' or i>= 19 and lettre == 'D' or j<=4 and lettre == 'H'  or j>= 15 and lettre == 'B'):
          if mat_sol[j+dico_orientation[lettre][2][0]][i+dico_orientation[lettre][2][1]] == 0 and mat_mur[j+dico_orientation[lettre][2][0]][i+dico_orientation[lettre][2][1]] != 61:
            endroit_possible.append((i,j))
  for x,y in endroit_possible:
    rectangle(x*52,y*52,x*52+52,y*52+52,couleur="green",tag="sort_vert",epaisseur=6)
  return endroit_possible

#Tests pour les données
def bonne_tuile(pion,pos,dico_orientation,bool):
  """permet de renvoyer un numéro de tuile aléatoire qui n'est pas déjà utilisé"""
  if len(convertir(liste_tuiles)) == 0 or "garde" in pion:
    return (0,0)
  tuiles_num = choice(convertir(liste_tuiles))
  if bool:
    for i in dico_orientation:
      if pion[-5]+i in dic_cases[mat_sol[pos[1]][pos[0]]]:
        return (tuiles_num,i)
    else:
      return (0,0)
  else:
    for i in dico_orientation:
      if i in dic_cases[mat_sol[pos[1]][pos[0]]]:
        return (tuiles_num,i)

def pions_mur(coord,lettre):
  """retourne un bolléen symbolisant si oui ou non un pion peu avancer en fonction des murs de la case ou il se trouve"""
  if mat_mur[coord[1]][coord[0]] != 0:
    return lettre not in dic_cases[mat_mur[coord[1]][coord[0]]]
  else:
    return True

def pions_pion(player,L):
  """Regarde dans L si il existe un pion au même coordonnées que player, si c'est le cas on renvoie False car on ne peux pas avancer
  ce pion dans cette case. player correspond aux coordonnées possible du pions sélectionné si on effectuais le déplacement choisi."""
  test = True
  for i in range(len(L)):
    if player == (Donnees_jeu[L[i]][0],Donnees_jeu[L[i]][1]): 
      test = False
  if mat_sol[player[1]][player[0]] == 0:
    return False
  return test

def objet_check():
  """regarde si les pions sont sur la position où se trouve leurs objet et si c'est le cas alors les objets et la sortie passe en true"""
  objet = True
  for i in Donnees_jeu:
    if mat_sol[Donnees_jeu[i][1]][Donnees_jeu[i][0]] != 0 and "garde" not in i:
      if dic_cases[mat_sol[Donnees_jeu[i][1]][Donnees_jeu[i][0]]] != 'images/objet/'+i[-5]+'.png':
        objet = False
  if objet:
    for i in Donnees_jeu:
      Donnees_jeu[i] = (Donnees_jeu[i][0],Donnees_jeu[i][1],Donnees_jeu[i][2],True)
      affichage()
    if Donnees_jeu["images/garde/6.png"][0] == -1:
      Donnees_jeu["images/garde/6.png"]=(11,11,False,False)
      Donnees_jeu["images/garde/7.png"]=(10,11,False,False)
    

def sortie_check(pion,pion_cord,pos):
  """regarde si le pion est sur la position où se trouve sa sortie et si c'est le cas alors l'objet passe en true"""
  sortie = 'images/sortie/'+pion[-5]+'.png'
  for j in range(len(mat_sol)):
      for k in range(len(mat_sol[0])):
        if mat_sol[j][k] != 0:
          if dic_cases[mat_sol[j][k]] == sortie and k == pion_cord[0] and j == pion_cord[1] and pion_cord[3]:
            Donnees_jeu[pion]= (Donnees_jeu[pion][0],Donnees_jeu[pion][1],True,Donnees_jeu[pion][3])
            return(changer_joueur(pion_select,liste_pion[0],pos))
               
def gagner_check():
  """test si la partie est gagné"""
  for i in Donnees_jeu:
    if not Donnees_jeu[i][2] and "garde" not in i:
      return False
  return True
    
def perdu_check(temp):
  """test si la partie est perdu en fonction du temp qu'il reste"""
  if int(temp) <= 0:
    return True

def test_gagner_perdu(L):
  """permet d'appeler les affiche si on à gagné ou perdu"""
  if L[1] == True:
    affichage_interm("Gagné !!!","Menu","Quitter",mat_sol,mat_mur,debut,Donnees_jeu,liste_tuiles,mat_tuiles)
    return True
  elif L[0] == True:
    affichage_interm("Perdu !!!","Menu","Quitter",mat_sol,mat_mur,debut,Donnees_jeu,liste_tuiles,mat_tuiles)
    return True

def appelpouvoir(list,pion):
  """Permet d'appeler les fonctions correspondant à tout les pouvoir possédé par un joueur sur un pion """
  for i in range(len(list)):
    if list[i] == "télé":
      teleportation(pion,(Donnees_jeu[pion][0],Donnees_jeu[pion][1]))
    elif list[i] == "esc":
      escalator(pion,(Donnees_jeu[pion][0],Donnees_jeu[pion][1]))
    elif list[i] == "expl":
      if mat_sol[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]] == 107 and "3" in pion:
        sort_violet((Donnees_jeu[pion][1],Donnees_jeu[pion][0]),2)
      if mat_mur[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]]!=0 and mat_mur[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]] == 0 and "2" in pion and mat_sol[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]] == 78 and "E" not in dic_cases[mat_mur[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]]] and "explo" not in dic_cases[mat_sol[Donnees_jeu[pion][1]][Donnees_jeu[pion][0]]]:
        sort_vert()
      exploration(pion,(Donnees_jeu[pion][0],Donnees_jeu[pion][1]))

def dans_tuile(quoi,tuile):
  """Permet de savoir si il existe une image contenant quoi dans la tuile avec le numéro tuile"""
  for i in range(len(mat_tuiles[0])):
    for j in range(len(mat_tuiles)):
      if mat_tuiles[j][i] == tuile:
        for k in range(1,8):
          if "images/"+quoi+"/"+str(k)+".png" in Donnees_jeu:
            if Donnees_jeu["images/"+quoi+"/"+str(k)+".png"][0] == i and Donnees_jeu["images/"+quoi+"/"+str(k)+".png"][1] == j:
              return True

def test_touches(debut,attente,pion_select,debug,direction_select,choix):
  """Attent que l'utilisateur utilise une touche et si c'est le cas fait ce pour quoi cette touche est faite"""
  touche = attente_touche_jusqua(attente)
  if touche == "dollar":
    debug = not debug
    if not debug:
      return(True,debut,pion_select,1000,debug)
  if debug:
    return(True,debut,pion_select,0.001,debug)   
  elif touche == "Escape":
    temp_pose = time()
    condition = affichage_interm("Pause:","Reprendre","Menu",mat_sol,mat_mur,debut,Donnees_jeu,liste_tuiles,mat_tuiles)
    efface_tout()
    if condition:
      return(False,debut,pion_select,1000,debug)
    debut += time()-temp_pose
    affichage()
    return(True,debut,pion_select,1000,debug)
  for i in range(3):
    if choix >= i:
      if touche == Touches[i][0]:
        appelpouvoir(pouvoir[i],pion_select[i])
      elif touche == Touches[i][1]:
        changer_joueur(pion_select,convertir(liste_pion),i)
      elif touche == Touches[i][2]:
        changer_joueur(direction_select[i],direction_posible[i],0)
      elif touche == Touches[i][3]:
        debut = bouger_pion(pion_select[i],direction_select[i][0],0,debut)
        return(True,debut,pion_select,1000,debug)
  return(True,debut,pion_select,1000,debug)
#--------------------------------------------------------Partie principal----------------------------------------------------------
if __name__ == "__main__":
  """boucle principal qui controle le jeu et la gestion des touches """
#Dictionnaire liant les numéro dans la matrice à une image 
  dic_cases = extraire_dictionnaire("txt/dic.txt",[])
  liste_touche = ["avancer","gauche","droite","reculer"]
#boucle du programme
  cree_fenetre(1450, 1080)
  while True:
    debut= time() 
    Donnees_jeu = {"images/pion/1.png":(10,11,False,False),"images/pion/2.png":(11,11,False,False),"images/pion/3.png":(10,12,False,False),"images/pion/4.png":(11,12,False,False),"images/garde/5.png":(-1,-1,False,False),"images/garde/6.png":(-1,-1,False,False),"images/garde/7.png":(-1,-1,False,False)}
    liste_tuiles = [["2","3","4","5","6","7","8","9","10","11","12","14","15","16","17","19","20"],[]]
    mat_tuiles = extraire_matrice("txt/matrice/Matrice_Tuiles/1.txt")
    Touches = [["s","q","d","z"],["l","k","m","o"],["Down","Left","Right","Up"]]
    choix = affichage_menu()
    efface_tout()
    if choix[0] == 'sauv':
      Donnees_jeu = extraire_dictionnaire("txt/Sauvegarde/dico_donnees",["images/pion/1.png","images/pion/2.png","images/pion/3.png","images/pion/4.png","images/garde/5.png","images/garde/6.png","images/garde/7.png"])
      mat_sol = extraire_matrice("txt/Sauvegarde/mat_sol.txt")
      mat_mur = extraire_matrice("txt/Sauvegarde/mat_mur.txt")
      debut-= 180-float(lire_fichier("txt/Sauvegarde/temps"))
      liste_tuiles = extraire_matrice("txt/Sauvegarde/liste_tuile")
      mat_tuiles = extraire_matrice("txt/Sauvegarde/mat_tuiles")
    else:
      mat_sol = extraire_matrice("txt/MatriceRendu"+choix[0]+"/mat_2.txt")
      mat_mur = extraire_matrice("txt/MatriceRendu"+choix[0]+"/mat_1.txt") 
    if choix[0] == "2":
      Donnees_jeu = {"images/pion/1.png":(11,7,False,False),"images/pion/2.png":(12,7,False,False),"images/pion/3.png":(11,8,False,False),"images/pion/4.png":(12,8,False,False),"images/garde/5.png":(-1,-1,False,False),"images/garde/6.png":(-1,-1,False,False),"images/garde/7.png":(-1,-1,False,False)}
    pion_select = ["images/pion/1.png"]*choix[1]
    direction_posible,pouvoir = affectation_direct_pvr(choix[1])
    direction_select = []
    for i in range(choix[1]):
      direction_select.append([direction_posible[i][0]])
    affichage()
    activer,debug,gagner,perdu= True,False,False,False
    liste_pion=[["images/pion/1.png", "images/pion/2.png", "images/pion/3.png", "images/pion/4.png", "images/garde/5.png", "images/garde/6.png", "images/garde/7.png"],[]]                                                                                                                                                                                                                                                                                             
    attente = 1
    pouvoir_vert = 0
#boucle principale
    while activer:
      if debug == True:
        pion_random = choice(convertir(liste_pion))
        debug_mode(pion_random, choice(liste_touche))
        exploration(pion_random,(Donnees_jeu[pion_random][0],Donnees_jeu[pion_random][1]))
        escalator(pion_random,(Donnees_jeu[pion_random][0],Donnees_jeu[pion_random][1]))
      activer,debut,pion_select,attente,debug = test_touches(debut,attente,pion_select,debug,direction_select,choix[1])
      test = test_gagner_perdu(affichage_main(pion_select,debug,debut,direction_select))
      if test:
        break