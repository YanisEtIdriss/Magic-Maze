Présentation (version du 11 janvier 2021) :
##############

-Qui a fait le projet ?
Projet réalisé par Idriss Bachi et Yanis Adjou.

-Qu’est-ce que c’est ?
Il s'agit d'un projet scolaire de première année de DUT informatique à l'UPEM, le but était de présenter une version jeux vidéo du célèbre jeu de plateau Magic Maze Par Kasper Lapp.

-Quand as-t’il était réalisé ?
Le projet a été lancé le lundi 12 octobre 2020, sa première version est sortie le 2 novembre 2020 la deuxième le 6 décembre 2020 et la troisième et la dernière le 10 janvier 2021.

-Comment on l’installe ?
Il suffit de posséder Python et tkinter sur son ordinateur et d'exécuter le fichier Main.py après avoir extrait le fichier zip.
Il est conseiller de jouer sur linux.

Comment le programme est-il organisé ?
######################################

Notre programme s'organise en plusieurs parties dont trois fichiers python, des fichiers texte ainsi qu'un dossier où l'on trouve toutes nos images utilisées dans le jeu :
---------------------------------------------

= Le dossier "images" qui possède toutes les images en PNG organisées dans d'autres dossiers.

= Les fichiers texte qui permettent une meilleure organisation dans le stockage d'informations de jeu:
	- mat_x.txt des dossiers "MatriceRendux': stocke les matrices qui permettent l'affichage des murs ainsi que des cases.
	- x.txt du dossier "règles" : Stocke l'affichage des règles accessibles via le menu.
	- dic.txt : Dictionnaire qui référencie toutes les images présentes dans notre jeu.
	- les fichiers du dossier "Sauvegardes'" qui stocke toutes les informations permettant de reprendre une partie sans en commencer une autre.

= Les fichiers python qui sont liés entre eux dont qui se servent des informations des fichiers textes:
	- menu.py : comprennent les fonctions qui gèrent l'affichage des différents menus.
	- fichiers.py : comprennent les fonctions qui gèrent la prise en charge des fichiers textes.
	- Main.py: le fichier principal de notre programme qui possède la majorité de notre code et qui met en lien tous les autres fichiers.
	

		La première partie sert à l'importation des modules dont le principal utilisés pour l'interface de notre jeu, upemtk ainsi que l'importation des autres fichiers python.
	_____________________________________________________________________________________________________________________________________________________________________________________________
		Ensuite, la majorité de notre programme repose sur des fonctions que l'on fait intervenir plus tard dans la boucle principale.
		Ces fonctions sont séparées par plusieurs parties :
		la première représente les fonctions gérant l'affichage des données ;
		la suivante représente les fonctions gérant les données que l'on initialise plus loin ;
		ensuite celles représentent les fonctions testant la validité de ces données en fonction des règles du jeu ;
		la dernière représente les fonctions permettant la lecture des fichiers txt extérieur.
	_____________________________________________________________________________________________________________________________________________________________________________________________
		Enfin, c'est là que commence notre boucle principale :
		Elle commence bien évidemment par notre petite ligne de commande familière " if __name__ == "__main__": " la première partie contribue à l'initialisation de dictionnaires et listes qui possèdent des données qui ne changeront jamais.
		La seconde partie est une boucle du programme permettant de rejouer à l'infini.
		La dernière partie est la boucle principale qui fonctionne constamment pendant le jeu. En effet, à l'aide des fonctions prédéfinies, ces derniers changes les variables précédemment initialiser. C'est cette partie qui permet à l'utilisateur de jouer.





Quels ont été nos choix techniques ?
###################################
V1.0:
-Un programme entièrement basé sur des fonctions afin d'anticiper la suite du projet;
-L'initialisation de dictionnaires possédant toutes les images à afficher et leurs emplacements ainsi que leur état. Avec cette méthode il est assez facile de connaitre l'emplacement de tel ou tel élément;
-Le timer fonctionne à l'aide de la fonction time() du module time, on stocke lorsque le moment ou le jeu est lancé dans début et à chaque affichage on fait le temps qu'il est maintenant moins celui qui était au début;
-Lorsqu'on met le jeu en pause on compte le temps qui sait écouler pendant cette pose et on rajoute celui-ci à début;
-Nous avons choisi d'utiliser plusieurs listes à trous pour rendre le programme plus efficace.

V2.0:
-La séparation du code en plusieurs fichiers rendant toutes code facilement lisible et organisé en fonction de son utilisation;
-Le changement de notre système de stockage qui passe du code brut au fichier txt pour certaines informations;
-On a choisi de stocker les règles ainsi que les matrices dans des fichiers texte afin de rendre le code plus lisible;
-La séparation du labyrinthe en deux matrices distincte. Les matrices donnent uniquement les informations sur le terrain, pour chaque case il y a un numéro que l'on relie à une image à l'aide du dictionnaire dic_cases. Cela permet notamment de gérer les murs en effet à chaque fois qu'un pion veut se déplacer on regarde le chemin de la case où il se trouve. Ce chemin a été créé spécialement pour indiquer dans quelle direction chacune des images ne permet pas d'aller. 

v3.0:
- Créer des matrices distinctes pour chaque sens de chaque tuile afin de vaforiser les performances au détriment du stockage.
- Les dimensions choisi permettent d'accueillir 20 tuiles cependant on ne peut en avoir que 18 afin d'augmenter les chances d'afficher tout les objets et sorties qui sont nécessaire pour finir le jeu.
- Les gardes sont considéré, sauf pour les téléporteurs et exploration, comme des pions normaux cela permet d'avoir qu'un seul selecteur afin d'améliorer le confort utilisateur.

Quels ont été les éventuels problèmes rencontrés ?
##################################################
V1.0:
La principale difficulté rencontrée fut de maintenir un code compréhensible et efficace. Nous avons donc beaucoup réfléchi sur les meilleurs maniérés de faire pour chaque chose implémenter. Le but était de ne pas faire des if et elif à la chaine;
Notre principal problème rencontré fut alors de tout penser en amont;
Malgré cela nous avons quand même rencontré des problèmes lorsque nous avons commencé à coder car nous n’avions pas totalement pensé à tout. Cependant comme nous avions des objectifs et de manière de faire clairement défini et un code lisible nous avons réussi à passer outre ces problèmes;
Au niveau des graphismes il a été difficile de faire en sorte que toutes les cases soient liées;
Trouver le compromis entre résolutions petites mais assez grand pour pouvoir faire quelque chose de propre.

V2.0:
-Premiers problèmes de la phase 2 est apparus au moment de l'avoir commencé tout en prévoyant les problèmes possibles que pourrait provoquer la phase 3:
-le changement de résolution de la fenêtre pour pouvoir imbriquer toutes les tuiles nécessaires
-les problèmes que pourrait nous faire rencontrer l'exploration de tuiles choisies aléatoirement parmi les tuiles déjà prédéfinies
-la séparation du labyrinthe en deux matrices distincte afin d'avoir un contrôle sur la fonction d'une case sans devoir passer par les murs qui s'y trouve et inversement.

v3.0:
- Certaine disposition de tuiles ne permettent pas d'explorer toutes celles-ci.
- L'affichage d'autant de cases nous à obliger à revoir l'efficacité des certaines fonction qui prennait trop de temps à s'executer.
- L'ajout de l'exploration, des gardes et des sorts de l'elf et de la magicienne on fait apparaître de nombreux cas particulier qu'il à fallut indentifier et corriger.
- Sur windows il y'a un bug fail_to_alocate_bitmap empechant de jouer correctement.

Changelog(ce qui a été implémenté):
###################################
Version 1.0 du Lundi 2nov :
--------------------------
-Jouable seulement en solo on contrôle les 4 pions et on peut prendre les objets et sortir.
-On peut choisir entre deux modes kids un avec des murs et l'autre sans-Le terrain est constitué d'un labyrinthe vide toujours identique mais d'on l'emplacement des objets, des pions ainsi que des sorties sont aléatoires parmi plusieurs cases présélectionnées.
-Il y a un timer qui affiche un décompte de 180 jusqu'à 0 une fois arriver à 0 s'est perdu.
-Il y a un sélecteur qui permet au joueur de toujours connaître le pion actuellement sélectionné.
-Il existe un mode débug permettant de déplacer les pions de façon aléatoire afin de tester le programme.
-Le jeu une fois lancé est rejouable à l'infini grâce à un menu disponible permettant de guider le joueur.
-Le menu du début possède l'option Règles qui affiche les règles du jeu mais aussi l'option paramètre qui n'est pas encore disponible.
-Les autres menus permettant uniquement de rejouer et de quitter, l'option sauvegardée n'est pas encore disponible.

Version 2.0 du Dimanche  6déc :
------------------------------
-Jouable de 1 joueur à 3 joueurs sur des touches différentes du clavier;
-Implémentation du système de sauvegarde;
-Petites améliorations graphiques;
-Ajout des cases sablier dans le jeu;
-Ajout des cases téléporteur dans le jeu;
-Ajout des cases escalator dans le jeu;
-Amélioration du labyrinthe Kids Mur.

Version 3.0 du Dimanche  11jan :
-------------------------------
-Nouveau labyrinthe (clasic) 
-Ajout du système d'exploration de tuiles dans 4 sens différent;
-Ajout de la fonctionalité 







