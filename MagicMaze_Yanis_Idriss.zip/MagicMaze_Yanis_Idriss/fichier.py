from time import time, sleep

#Fonction sur les fichiers
def lire_fichier(chemin):
  """Lis un fichier et renvoie son texte"""
  with open(chemin, 'r') as fichier:
    texte = ""
    for lignes in fichier:
      texte += lignes
    fichier.close() 
  return texte

def extraire_matrice(chemin):
  """Lis un fichier et renvoie la matrice qu'il contient"""
  with open(chemin, 'r') as fichier:
    mat = []
    for lignes in fichier:
      mat.append([])
      L = lignes.strip().split(",")
      for i in range(len(L)):
        if L[i]!='':
          mat[-1].append(int(L[i]))
  return mat 

def extraire_dictionnaire(chemin,liste):
  """retourner des valeur sous forme de liste pas un str nullosse"""
  with open(chemin, 'r') as fichier:
    dic = dict()
    n = 1
    if len(liste) == 0:
      for lignes in fichier:
        dic[n]=lignes[:-1]
        n+=1
      return dic 
    n=0
    for lignes in fichier:
      L = lignes.strip().split(",")
      for i in range(len(L)):
        if L[i] == ' True':
          L[i] = True
        elif L[i] == ' False':
          L[i] = False
        else:
          L[i] = int(L[i])
      dic[liste[n]]=tuple(L)
      n+=1
    return dic 

def ecrire_Temp(debut):
  with open("txt/Sauvegarde/temps", 'w') as fichier1:
    fichier1.write(str(180-(time()-debut)))

def ecrire_dictionnaire(dico):
  with open("txt/Sauvegarde/dico_donnees", 'w') as fichier1:
    for i in dico.values():
      fichier1.write(str(i)[1:-1]+"\n")

def ecrire_matrice(mat,chemin):
  with open(chemin, 'w') as fichier1:
    for y in range(len(mat)):
      if y != 0:
        fichier1.write("\n")
      for x in range(len(mat[y])):
        fichier1.write(str(mat[y][x])+",")

def sauvegarder(mat_sol,mat_mur,debut,Donnees_jeu,liste_tuiles,mat_tuiles):
  ecrire_Temp(debut)
  ecrire_dictionnaire(Donnees_jeu)
  ecrire_matrice(mat_mur,"txt/Sauvegarde/mat_mur.txt")
  ecrire_matrice(mat_sol,"txt/Sauvegarde/mat_sol.txt")
  ecrire_matrice(liste_tuiles,"txt/Sauvegarde/liste_tuile")
  ecrire_matrice(mat_tuiles,"txt/Sauvegarde/mat_tuiles")